function add(a, b) {
  return a + b;
}

console.log(add(3, 4)); // 7
