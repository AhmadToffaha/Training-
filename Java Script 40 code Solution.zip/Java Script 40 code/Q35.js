const settings = { theme: "light", lang: "en" };

if (settings.theme === "light") settings.theme = "dark";
else settings.theme = "light";

console.log(settings);
