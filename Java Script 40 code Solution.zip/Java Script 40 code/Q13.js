let i = 0;

while (i < 3) {
  console.log(i);
  i++;
}
