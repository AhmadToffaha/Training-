const book = {
  title: "Genuis",
  author: "Ahmad Toffaha",
  year: 2008
};

console.log(book.title);
