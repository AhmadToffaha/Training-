let nums = [5, 2, 9, 1];

nums.push(10);
nums.shift();

console.log(nums);
console.log(nums.length);
