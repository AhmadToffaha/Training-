let x = 0;

if (x) {
  console.log("truthy");
} else {
  console.log("falsy");
}


