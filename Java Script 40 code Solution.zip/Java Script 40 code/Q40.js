let cities = ["Cairo", "Dubai", "Amman", "Doha", "Riyadh"];

cities.splice(1, 2);

console.log(cities);
