const greet = function (name) {
  return `Hello, ${name}`;
};

console.log(greet("Anas"));
