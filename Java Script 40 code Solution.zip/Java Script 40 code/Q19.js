
const color = "green";

switch (color) {
  case "red": console.log("stop"); break;
  case "yellow": console.log("slow"); break;
  default: console.log("go");
}

