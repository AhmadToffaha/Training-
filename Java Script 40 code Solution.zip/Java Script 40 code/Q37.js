let letters = ["b", "a", "c"];

letters.sort();

console.log(letters);
