setTimeout(function () {
  console.log("done");
}, 500);
