const user = { first: "Nader", last: "Hantash" };

function fullName(user) {
  return `${user.first} ${user.last}`;
}

console.log(fullName(user));
