// Q39: Use splice to insert "blue" at index 1
let colors = ["red", "green"];

colors.splice(1, 0, "blue");

console.log(colors); 
