let i = 5;

while (i > 0) {
  console.log(i);
  i--;
}
