let count = 0;

do {
  count++;
  console.log("count =", count);
} while (count < 3);
