const age = 15;

let status;
if (age < 13) status = "child";
else if (age <= 17) status = "teen";
else status = "adult";

console.log(status);
