let temp = 30;

if (temp > 30) console.log("hot");
else if (temp >= 20) console.log("warm");
else console.log("cold");
