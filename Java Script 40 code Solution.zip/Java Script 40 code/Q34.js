const person = { name: "Lina", age: 25 };

console.log("Before:", person);

person.age = 26;

console.log("After:", person);
