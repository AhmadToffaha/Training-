function isEven(n) {
  return n % 2 === 0;
}

const n = 11;

if (isEven(n)) console.log("even");
else console.log("odd");
