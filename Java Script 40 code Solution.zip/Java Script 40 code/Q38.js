let scores = [40, 100, 1, 5, 25, 10];

scores.sort((a, b) => a - b);

console.log(scores); 
