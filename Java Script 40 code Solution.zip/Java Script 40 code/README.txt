JavaScript Second — 40 Code Challenges (Solutions)
----------------------------------------------------------
Each question is in its own file: Q01.js ... Q40.js

How to run (example):
  node Q01.js

Note: Some files include comments showing the expected output.
