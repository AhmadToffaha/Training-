let num = -5;

if (num > 0) console.log("positive");
else if (num < 0) console.log("negative");
else console.log("zero");
