let count = 0;

for (let i = 1; i <= 50; i++) {
  if (i % 2 === 0 && i % 5 === 0) count++;
}

console.log(count); 
