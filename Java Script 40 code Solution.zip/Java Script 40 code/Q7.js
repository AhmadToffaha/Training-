let n = 7;

if (n % 2 === 0) console.log("even");
else console.log("odd");
